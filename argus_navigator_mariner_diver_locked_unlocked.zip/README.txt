Argus approved Navigator, Mariner and Diver badge artwork.
Unlocked PNGs are byte-for-byte identical to approved masters.
Locked PNGs apply grayscale and 0.64 brightness while retaining the original alpha channel.
All files are 512x512 RGBA PNG.
